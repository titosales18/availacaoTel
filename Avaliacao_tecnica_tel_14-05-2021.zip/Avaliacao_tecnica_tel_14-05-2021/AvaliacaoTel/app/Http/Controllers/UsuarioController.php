<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UsuarioController extends Controller
{
    public function index(){
        $usuário = [
            0 => ['nome' => 'nome',
                  'status' => 'N',
                  'email' => 'e-mail',

               ]
        ];



        return view('site.layouts.basico');

    }

    public function cadastra(){
        echo('cadastrado');
    }
}

