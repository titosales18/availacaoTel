<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <title>AVALIACAO_TEL </title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="<?php echo e(asset('css/avalia_tel.css')); ?>">
    </head>

    <body>
        <form method="POST"   action="cliente.php">

            <label>Nome</label><input type="text" name="nome" id="nome">
            <br>
            <label>CPF</label><input type="text" name="cpf" id="cpf">
            <br>
            <label>RG</label><input type="text" name="rg" id="rg">
            <br>
            <input type="submit" value="cadastrar">
        </form>
        <select>
            <option value="">Selecione</option>
            <option value="BA">Bahia</option>
            <option value="SP">São Paulo</option>
        </select>

        <script language ="JavaScript" >

        var SP = Sao Paulo;
        if ($Sp = Sao Paulo)  {
            echo 'Informe o RG:';
        }
        else if (){

        }
        tipo = 0.8;
}


    </body>

</html>
<?php /**PATH C:\xampp\htdocs\Avaliacao_tecnica_tel_14-05-2021\AvaliacaoTel\resources\views/site/layouts/cliente.blade.php ENDPATH**/ ?>