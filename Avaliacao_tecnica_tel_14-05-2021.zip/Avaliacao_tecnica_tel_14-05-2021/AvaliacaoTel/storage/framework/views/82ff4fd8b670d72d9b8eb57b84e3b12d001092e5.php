<div class="topo">

            <div class="logo">
                <img src= <?php echo e(asset('img/logo.png')); ?>>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="<?php echo e(route('site.index')); ?>">Home</a></li>
                    <li><a href="<?php echo e(route('site.sobrenos')); ?>">Sobre Nós</a></li>
                    <li><a href="<?php echo e(route('site.contato')); ?>">Contato</a></li>
                </ul>
            </div>
        </div>
<?php /**PATH C:\xampp\htdocs\Avaliacao_tecnica_tel_14-05-2021\AvaliacaoTel\resources\views/site/layouts/_partials/topo.blade.php ENDPATH**/ ?>