<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <title>AVALIACAO_TEL </title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="<?php echo e(asset('css/avalia_tel.css')); ?>">
    </head>

    <body>
        <form method="GET"   action="<?php echo e(url('usuario_cadastra')); ?>">

            <label>Usuario</label><input type="text" name="usuario" id="usuario">
            <br>
            <label>Senha</label><input type="password" name="senha" id="senha">
            <br>
            <label>E-mail</label><input type="text" name="email" id="email">
            <br>
            <input type="submit" value="cadastrar">

        </form>
    </body>
</html>

<?php /**PATH C:\xampp\htdocs\Avaliacao_tecnica_tel_14-05-2021\AvaliacaoTel\resources\views/site/layouts/basico.blade.php ENDPATH**/ ?>