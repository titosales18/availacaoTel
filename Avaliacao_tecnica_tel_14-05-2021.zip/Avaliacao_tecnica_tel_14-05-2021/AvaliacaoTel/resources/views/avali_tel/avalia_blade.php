@extends('site.layouts.basico')

        @section('titulo', $titulo )


        @section('conteudo')



        <div class="conteudo-pagina">
            <div class="titulo-pagina">
                <h1>Cadastro</h1>
            </div>

            <div class="informacao-pagina">
                <div class="contato-principal">
             @component('site.layouts._components.form_contato', ['classe' => 'borda-preta'])
                    <p>Avalia_TEL</p>
             @endcomponent
                </div>
            </div>
        </div>

        <div class="rodape">
            <div class="area-contato">
                <h2>Contato</h2>
                <span>(11) 3333-4444</span>
                <br>
                <span>supergestao@dominio.com.br</span>
            </div>
            <div class="localizacao">
                <h2>Localização</h2>
            </div>
        </div>
@endsection()
