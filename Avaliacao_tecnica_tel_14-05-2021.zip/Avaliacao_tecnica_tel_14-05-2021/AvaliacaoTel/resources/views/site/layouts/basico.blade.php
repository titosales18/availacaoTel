<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <title>AVALIACAO_TEL </title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="{{asset('css/avalia_tel.css') }}">
    </head>

    <body>
        <form method="GET"   action="{{ url('usuario_cadastra') }}">

            <label>Usuario</label><input type="text" name="usuario" id="usuario">
            <br>
            <label>Senha</label><input type="password" name="senha" id="senha">
            <br>
            <label>E-mail</label><input type="text" name="email" id="email">
            <br>
            <input type="submit" value="cadastrar">

        </form>
    </body>
</html>

