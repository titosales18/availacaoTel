    {{ $slot }}

    <form action {{route ('site.usuário')}} method="post">
        @csrf
        <input name="nome" type="text" placeholder="Nome" class="{{ $classe }}">
        <br>
        <input name="telefone" type="text" placeholder="Telefone" class="{{ $classe }}">
        <br>
        <input name="email" type="text" placeholder="E-mail" class="{{ $classe }}">
        <br>
        <select name="motivo_contato" class="{{ $classe }}">
            <option value="">Informe nome</option>
            <option value="1">Informe e-mail</option>
            <option value="2">Informe senha</option>
        </select>
        <br>
        <textarea name="mensagem" class="{{ $classe }}">Preencha aqui a sua mensagem</textarea>
        <br>
        <button type="submit" class="{{ $classe }}">ENVIAR</button>
    </form>
