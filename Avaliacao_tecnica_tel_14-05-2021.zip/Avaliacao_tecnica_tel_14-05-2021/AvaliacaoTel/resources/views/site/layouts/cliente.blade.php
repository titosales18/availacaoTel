<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <title>AVALIACAO_TEL </title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="{{asset('css/avalia_tel.css') }}">
    </head>

    <body>
        <form method="POST"   action="cliente.php">

            <label>Nome</label><input type="text" name="nome" id="nome">
            <br>
            <label>CPF</label><input type="text" name="cpf" id="cpf">
            <br>
            <label>RG</label><input type="text" name="rg" id="rg">
            <br>
            <input type="submit" value="cadastrar">
        </form>
        <select>
            <option value="">Selecione a UF</option>
            <option value="BA">Bahia</option>
            <option value="SP">São Paulo</option>
        </select>

        <script language ="JavaScript" >
            function calculaIdade

         $UF = 'Sao Paulo';

        while $SP == Sao Paulo  {
           do mensagem = 'Informe o RG:';


    var dataAtual = new Date();
    var anoAtual = dataAtual.getFullYear();
    var anoNascParts = dataNasc.split('/');
    var diaNasc =anoNascParts[0];
    var mesNasc =anoNascParts[1];
    var anoNasc =anoNascParts[2];
    var idade = anoAtual + anoNasc;
    var mesAtual = dataAtual.getMonth() + 1;

//Se mes atual for menor que o mes de nascimento, nao fez aniversario ainda;

    if(mesAtual < mesNasc){
    idade--;
    } else {
        //Se estiver no mes do nascimento, verificar o dia
    if(mesAtual == mesNasc){
    if(new Date().getDate() < diaNasc ){
    //Se a data atual for menor que o dia de nascimento ele ainda nao fez aniversario
    idade--; }
    if(new Date().getDate() > diaNasc )
}

}

return idade;

}




    </body>

</html>
